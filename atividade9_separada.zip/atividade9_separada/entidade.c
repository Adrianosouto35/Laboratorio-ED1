#include "entidade.h"
#include <stdlib.h>
#include <math.h>

Entidade *entidadeCriar(TipoEntidade tipo, Vector2 pos) {
    Entidade *e = malloc(sizeof(Entidade));
    if (e == NULL) return NULL;

    e->tipo = tipo;
    e->pos = pos;
    e->raio = 14.0f;
    e->vida = 100;

    switch (tipo) {
        case ENTIDADE_JOGADOR:
            e->raio = 16.0f;
            e->vida = 100;
            e->extra.dano = 10;
            break;
        case ENTIDADE_INIMIGO:
            e->raio = 14.0f;
            e->vida = 40;
            e->extra.dano = 1;
            break;
        case ENTIDADE_ITEM:
            e->raio = 10.0f;
            e->vida = 1;
            e->extra.valor = 10;
            break;
    }

    return e;
}

bool entidadeColidiu(const Entidade *a, const Entidade *b) {
    if (a == NULL || b == NULL) return false;

    float dx = a->pos.x - b->pos.x;
    float dy = a->pos.y - b->pos.y;
    float distancia = sqrtf(dx * dx + dy * dy);

    return distancia <= a->raio + b->raio;
}

void entidadeAplicarDano(Entidade *entidade, int dano) {
    if (entidade == NULL || dano < 0) return;

    entidade->vida -= dano;
    if (entidade->vida < 0) entidade->vida = 0;
}

void entidadeDesenhar(const Entidade *entidade) {
    if (entidade == NULL) return;

    switch (entidade->tipo) {
        case ENTIDADE_JOGADOR:
            DrawCircleV(entidade->pos, entidade->raio, BLUE);
            DrawCircleLines((int)entidade->pos.x, (int)entidade->pos.y,
                            entidade->raio, DARKBLUE);
            break;
        case ENTIDADE_INIMIGO:
            DrawCircleV(entidade->pos, entidade->raio, RED);
            DrawCircleLines((int)entidade->pos.x, (int)entidade->pos.y,
                            entidade->raio, MAROON);
            break;
        case ENTIDADE_ITEM:
            DrawCircleV(entidade->pos, entidade->raio, GOLD);
            DrawCircleLines((int)entidade->pos.x, (int)entidade->pos.y,
                            entidade->raio, ORANGE);
            break;
    }
}
