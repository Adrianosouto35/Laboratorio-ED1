#ifndef ENTIDADE_H
#define ENTIDADE_H

#include "raylib.h"
#include <stdbool.h>

typedef enum {
    ENTIDADE_JOGADOR,
    ENTIDADE_INIMIGO,
    ENTIDADE_ITEM
} TipoEntidade;

typedef struct Entidade Entidade;

struct Entidade {
    TipoEntidade tipo;
    Vector2 pos;
    int vida;
    float raio;
    union {
        int valor;
        int dano;
    } extra;
};

Entidade *entidadeCriar(TipoEntidade tipo, Vector2 pos);
bool entidadeColidiu(const Entidade *a, const Entidade *b);
void entidadeAplicarDano(Entidade *entidade, int dano);
void entidadeDesenhar(const Entidade *entidade);

#endif
