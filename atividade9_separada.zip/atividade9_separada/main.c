#include "raylib.h"
#include "entidade.h"
#include "inventario.h"
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

#define LARGURA_JANELA 800
#define ALTURA_JANELA 600
#define MAX_ENTIDADES 30
#define TOTAL_INIMIGOS 5
#define TOTAL_ITENS 6
#define DANO_TIRO 20

int main(void) {
    srand((unsigned int)time(NULL));

    InitWindow(LARGURA_JANELA, ALTURA_JANELA,
               "Atividade 9 - TAD (Tipo Abstrato de Dados)");
    SetTargetFPS(60);

    Inventario *inventario = inventarioCriar(MAX_ENTIDADES);
    if (inventario == NULL) {
        CloseWindow();
        return 1;
    }

    Entidade *jogador = entidadeCriar(
        ENTIDADE_JOGADOR,
        (Vector2){LARGURA_JANELA / 2.0f, ALTURA_JANELA / 2.0f}
    );

    if (jogador == NULL || !inventarioAdicionar(inventario, jogador)) {
        free(jogador);
        inventarioDestruir(inventario);
        CloseWindow();
        return 1;
    }

    for (int i = 0; i < TOTAL_INIMIGOS; i++) {
        Vector2 pos = {
            (float)GetRandomValue(30, LARGURA_JANELA - 30),
            (float)GetRandomValue(65, ALTURA_JANELA - 30)
        };
        Entidade *inimigo = entidadeCriar(ENTIDADE_INIMIGO, pos);
        if (inimigo != NULL && !inventarioAdicionar(inventario, inimigo)) {
            free(inimigo);
        }
    }

    for (int i = 0; i < TOTAL_ITENS; i++) {
        Vector2 pos = {
            (float)GetRandomValue(30, LARGURA_JANELA - 30),
            (float)GetRandomValue(65, ALTURA_JANELA - 30)
        };
        Entidade *item = entidadeCriar(ENTIDADE_ITEM, pos);
        if (item != NULL && !inventarioAdicionar(inventario, item)) {
            free(item);
        }
    }

    int pontuacao = 0;
    float tempoAviso = 0.0f;
    float tempoDesdeDano = 0.0f;

    while (!WindowShouldClose()) {
        float dt = GetFrameTime();
        float vel = 250.0f * dt;
        tempoDesdeDano += dt;

        if (jogador->vida > 0) {
            if (IsKeyDown(KEY_RIGHT)) jogador->pos.x += vel;
            if (IsKeyDown(KEY_LEFT)) jogador->pos.x -= vel;
            if (IsKeyDown(KEY_UP)) jogador->pos.y -= vel;
            if (IsKeyDown(KEY_DOWN)) jogador->pos.y += vel;
        }

        if (jogador->pos.x < jogador->raio) jogador->pos.x = jogador->raio;
        if (jogador->pos.x > LARGURA_JANELA - jogador->raio)
            jogador->pos.x = LARGURA_JANELA - jogador->raio;
        if (jogador->pos.y < 60 + jogador->raio)
            jogador->pos.y = 60 + jogador->raio;
        if (jogador->pos.y > ALTURA_JANELA - jogador->raio)
            jogador->pos.y = ALTURA_JANELA - jogador->raio;

        if (jogador->vida > 0) {
            for (int i = 1; i < inventarioTotal(inventario); i++) {
                Entidade *e = inventarioObter(inventario, i);
                if (e == NULL || !entidadeColidiu(jogador, e)) continue;

                if (e->tipo == ENTIDADE_ITEM) {
                    pontuacao += e->extra.valor;
                    inventarioRemover(inventario, i);
                    i--;
                } else if (e->tipo == ENTIDADE_INIMIGO && tempoDesdeDano >= 0.5f) {
                    entidadeAplicarDano(jogador, e->extra.dano);
                    tempoDesdeDano = 0.0f;
                }
            }
        }

        if (jogador->vida > 0 && IsKeyPressed(KEY_SPACE)) {
            int alvo = -1;
            float menorDistancia = 999999999.0f;

            for (int i = 1; i < inventarioTotal(inventario); i++) {
                Entidade *e = inventarioObter(inventario, i);
                if (e == NULL || e->tipo != ENTIDADE_INIMIGO) continue;

                float dx = e->pos.x - jogador->pos.x;
                float dy = e->pos.y - jogador->pos.y;
                float distancia = dx * dx + dy * dy;

                if (distancia < menorDistancia) {
                    menorDistancia = distancia;
                    alvo = i;
                }
            }

            if (alvo >= 0) {
                Entidade *e = inventarioObter(inventario, alvo);
                entidadeAplicarDano(e, DANO_TIRO);
                if (e->vida <= 0) inventarioRemover(inventario, alvo);
            }
        }

        if (inventarioEstaCheio(inventario)) {
            tempoAviso = 1.5f;
        } else if (tempoAviso > 0.0f) {
            tempoAviso -= dt;
        }

        int itensRestantes = inventarioContarPorTipo(inventario, ENTIDADE_ITEM);
        int inimigosRestantes = inventarioContarPorTipo(inventario, ENTIDADE_INIMIGO);

        BeginDrawing();
            ClearBackground(RAYWHITE);
            DrawRectangle(0, 0, LARGURA_JANELA, 55, (Color){235, 239, 245, 255});

            for (int i = 0; i < inventarioTotal(inventario); i++) {
                entidadeDesenhar(inventarioObter(inventario, i));
            }

            DrawText(TextFormat("Vida: %d   Pontuacao: %d", jogador->vida, pontuacao),
                     10, 7, 20, DARKGRAY);
            DrawText(TextFormat("Entidades: %d/%d",
                                inventarioTotal(inventario), MAX_ENTIDADES),
                     10, 32, 16, GRAY);
            DrawText(TextFormat("Itens: %d   Inimigos: %d",
                                itensRestantes, inimigosRestantes),
                     390, 32, 16, DARKGRAY);

            if (tempoAviso > 0.0f) {
                DrawRectangle(180, 75, 440, 42, (Color){255, 220, 220, 255});
                DrawText("AVISO: INVENTARIO CHEIO!", 220, 86, 22, RED);
            }

            if (jogador->vida <= 0) {
                DrawRectangle(150, 240, 500, 100, (Color){255, 230, 230, 245});
                DrawText("VOCE FOI DERROTADO!", 230, 260, 30, RED);
                DrawText("Pressione ESC para sair.", 265, 300, 18, DARKGRAY);
            }

            DrawText("Setas movem | ESPACO ataca | ESC sai",
                     10, ALTURA_JANELA - 25, 16, GRAY);
        EndDrawing();
    }

    inventarioDestruir(inventario);
    CloseWindow();
    return 0;
}
